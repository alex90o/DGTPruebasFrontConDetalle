import React from "react";
import UsarAPI from './UsarAPI/UsarAPI.js';
/*
const producto= {
    id,
    nombre,
    description,
    precio,
    cantidad,
    imagen
}
*/
class ProductosAPI extends React.Component {
    constructor(props){
        super(props)
        this.state={
        productos:[]
        }
        //producto.getProductos


    }


    componentDidMount(){
        UsarAPI.getProductos().then((response)=>{
                this.setState({
                    productos:response.data
                })
            }
        )
    }


    render(){
        return( 
            

        <div>
            {console.log(this.state.productos)}
              <div class="table-responsive">
                <table className="table table-bordered" Style="text-align: center">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th>descripcion</th>
                        <th>precio</th>
                        <th>cantidad</th>
                        <th>imagen</th>
                    </tr>
                    </thead>
                    <tbody>
                    {
                        this.state.productos.map(producto=>
                    
                    
                    <tr>
                        <td><h4>{producto.id}</h4></td>
                        <td><h4>{producto.nombre}</h4></td>
                        <td><h4>{producto.descripcion}</h4></td>
                        <td><h4>${producto.precio}</h4></td>
                        <td><h4>{producto.cantidad}</h4></td>
                        <td><h4>{producto.imagen}</h4></td>
                    </tr>
                        )
                        } 
                    </tbody>
                    </table>
                
                </div>

            </div>
        
        )
    }
}
export default ProductosAPI;