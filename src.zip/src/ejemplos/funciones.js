


const saludo = "Sarasa ñaolksdjf"


export const saludar = () => {
    console.log(saludo)
  }
