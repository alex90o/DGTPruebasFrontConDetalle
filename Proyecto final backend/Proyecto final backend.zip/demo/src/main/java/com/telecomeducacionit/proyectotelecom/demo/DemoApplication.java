package com.telecomeducacionit.proyectotelecom.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.telecomeducacionit.DAO.IProductoDAO;
import com.telecomeducacionit.entidades.Producto;

@SpringBootApplication
@ComponentScan(basePackages="com.telecomeducacionit")
@EntityScan("com.telecomeducacionit")
@EnableJpaRepositories("com.telecomeducacionit")
public class DemoApplication implements CommandLineRunner {
@Autowired
IProductoDAO proDAO;
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
		/*Producto p1 = new Producto(1, "iphone 12 pro" , "iphone 12 pro", 23000.00, 8,"tecnologia","http://d3ugyf2ht6aenh.cloudfront.net/stores/001/054/848/products/graphite1-c6a0ea330d5a8a5ddb16245702688771-640-0.png"); //http://localhost:8080/api/productos/1 para ese solo producto
		
		Producto p2 = new Producto(2,"notebook" ,"core i7, 10ma gen",120000.00, 20,"tecnologia", "http://d3ugyf2ht6aenh.cloudfront.net/stores/892/141/products/hp-notebook-15-dy1078nr-1221-520109b6ea5398cdcf15984550860111-640-0.jpg");
		
		Producto p3 = new Producto(3,"tripode base" ,"tripode, palo selfie",1800.00, 20,"accesorios", "https://d2r9epyceweg5n.cloudfront.net/stores/001/231/930/products/k07-mobile-phone-bluetooth-selfie-stick-with-tripod-integrated-multi-function-mini-photo-live-artifact-universal-jpg_640x6401-f21e95ce7b0b86afbe16027065076032-640-01-996aa8eb75cebcfcf016306765744548-640-0.jpg");
		
		Producto p4 = new Producto(4,"smartwach","smartwatch sumergible", 6000.00, 20,"accesorios", "https://www.mylshop.com.ar/wp-content/uploads/2021/01/reloj-inteligente-deportivo-t03-ip68-reloj-inteligente-deportivo-con-control-de-temperatura-continua-de-24-horas1-f2e6e90a6f4e23ce3916068633265287-640-0.jpg");
		
		proDAO.save(p1);
		proDAO.save(p2);
		proDAO.save(p3);
		proDAO.save(p4);
		*/
		//Producto p4 = new Producto(4,"smartwach","smartwatch sumergible", 6000.00, 20,"accesorios", "https://www.mylshop.com.ar/wp-content/uploads/2021/01/reloj-inteligente-deportivo-t03-ip68-reloj-inteligente-deportivo-con-control-de-temperatura-continua-de-24-horas1-f2e6e90a6f4e23ce3916068633265287-640-0.jpg");
		//proDAO.save(p4);
		
		//proDAO.deleteById(4);
		
		/*
		Producto p1 = new Producto(5, "Impresora HP" , "Imprimí archivos, escaneá documentos y hacé todas las fotocopias que necesités con esta impresora multifunción HP",9999.00, 10,"tecnologia","http://www.resinformatica.com.ar/Temp/App_WebSite/App_PictureFiles/Items/4490_800.jpg");
		
		Producto p2 = new Producto(6,"PC Kelyx AMD Athlon320","Combo cpu mas teclado, mouse y parlantes",45400.00,15,"tecnologia","http://www.resinformatica.com.ar/Temp/App_WebSite/App_PictureFiles/Items/4475_800.jpg");
		
		Producto p3 = new Producto(7,"Tablet Lenovo" ,"La tablet Lenovo YTX705F cuenta con entrada audio jack 3.5 mm y puerto micro USB 2.0.",48300.00, 30,"tecnologia","https://images.fravega.com/f1000/c9f97b195f09106a00593a967b6241e2.jpg");
		
		Producto p4 = new Producto(8,"Celular Sansung Galaxy A51","Con el almacenamiento expandible de 512 GB podrás dejar de preocuparte por el espacio de la memoria", 55200.00, 15,"tecnologia", "https://images.samsung.com/is/image/samsung/ar-galaxy-a51-a515-sm-a515fzklaro-front-299685233?$684_547_PNG$");
		*/
		
		/*
		Producto p1 = new Producto(9, "Soporte para Tablet SOUL" , "Soporte para Tablet de 7″ y 10″. Con ventosa para vidrio y con soporte para apoyacabeza", 1490.00, 30,"accesorios", "https://www.mylshop.com.ar/wp-content/uploads/2019/09/soporte-tablet-auto-ipad-samsung-asus-acer-de-7-14-calidad-D_NQ_NP_665235-MLA31054545379_062019-Q.jpg");
		
		Producto p2 = new Producto(10,"Mouse inalámbrico Logitech M190" ,"Logitech M190 es un mouse inalámbrico de tamaño normal con un confortable diseño contorneado",2340.00, 10,"accesorios","https://bangho.vteximg.com.br/arquivos/ids/159960-590-590/MOUSE-LOGITECH-M190--1-.jpg?v=637559924444870000");
		
		Producto p3 = new Producto(11,"Notebook Banghó Max L4" ,"Con la Notebook Banghó Max L4 i1 Microsoft 365 Personal, podrás llevar tus archivos y documentos a todos lados gracias a su peso ligero y tamaño reducido sin perder prestaciones",61890.00, 5,"tecnologia", "http://www.resinformatica.com.ar/Temp/App_WebSite/App_PictureFiles/Items/4229_800.jpg");
		
		Producto p4 = new Producto(12,"Adaptador para Auriculares","Adaptador para Auriculares con microfono 3.5mm", 460.00, 20,"accesorios","https://http2.mlstatic.com/D_631819-MLA31352271834_072019-O.jpg");
		*/
		
		Producto p1 = new Producto(13, "Auricular MSI" , "Auricular MSI DS501 gaming de color rojo y negro con microfono incorporado", 13590.00, 10,"accesorios","http://www.resinformatica.com.ar/Temp/App_WebSite/App_PictureFiles/Items/1341_800.jpg");
		
		Producto p2 = new Producto(14,"Notebook DELL Latitude 3410" ,"Intel® Core™ i5-10210U (Caché de 6 M, hasta 4,20 GHz)",97850.00, 10,"tecnologia","https://http2.mlstatic.com/D_NQ_NP_995563-MLA43652886047_102020-O.jpg");
		
		Producto p3 = new Producto(15,"Cpu Dell Optiplex" ,"Procesador doble nucleo, Disco duro 320 GB, RAM: 4 GB, Sistema operativo: Windows 10",48620.00, 10,"tecnologia", "https://http2.mlstatic.com/D_NQ_NP_965319-MLM43582391744_092020-O.jpg");
		
		Producto p4 = new Producto(16,"Monitor 22 led Asus","Tamaño de panel: 21,5 (54,6 cm) 16:9 Panorámica, Resolución real: 1920x1080", 35890.00, 20,"accesorios", "https://www.venex.com.ar/products_images/1585842748_monitor_22_led_asus_vp228he_cf_fhd_1ms_75hz.jpg");
		
		proDAO.save(p1);
		proDAO.save(p2);
		proDAO.save(p3);
		proDAO.save(p4);
		
		
		Producto p17 = new Producto(17, "Silla Gamer AUREOX" ,"Superficie de Cuero Sintético y Estructura de Acero", 34200.00, 20,"accesorios","http://www.resinformatica.com.ar/Temp/App_WebSite/App_PictureFiles/Items/4041_800.jpg");
		proDAO.save(p17);
		  
	}
	
	 
}
